package com.second

fun getResult() = "This is from Second module"